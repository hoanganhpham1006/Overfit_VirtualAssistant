import re
from text import cleaners
from text.symbols import vn_symbols, en_symbols
from unicodedata import normalize
from underthesea import word_tokenize
import re
from num2words import num2words

vn_symbol_to_id = {s: i for i, s in enumerate(vn_symbols)}
vn_id_to_symbol = {i: s for i, s in enumerate(vn_symbols)}

en_symbol_to_id = {s: i for i, s in enumerate(en_symbols)}
en_id_to_symbol = {i: s for i, s in enumerate(en_symbols)}

_curly_re = re.compile(r'(.*?)\{(.+?)\}(.*)')


def vi_num2words(num):
    return num2words(num, lang='vi')


def convert_time_to_text(time_string):
    try:
        h, m = time_string.split(":")
        time_string = vi_num2words(int(h)) + " giờ " + \
            vi_num2words(int(m)) + " phút"
        return time_string
    except:
        return None


def replace_time(text):
    result = re.findall(r'\d{1,2}:\d{1,2}|', text)
    match_list = list(filter(lambda x: len(x), result))

    for match in match_list:
        if convert_time_to_text(match):
            text = text.replace(match, convert_time_to_text(match))
    return text


def replace_number(text):
    return re.sub('(?P<id>\d+)', lambda m: vi_num2words(int(m.group('id'))), text)


def normalize_text(text, language):
    text = text.strip()
    text = normalize("NFC", text)
    text = text.lower()
    text = re.sub("\s+", " ", text)
    text = replace_time(text)
    text = replace_number(text)
    text = word_tokenize(text, format="text")
    if language == 'vn':
      text = "-- {} ..".format(text)
    return text


def text_to_sequence(text, cleaner_names, language, normalize=True):
  sequence = []
  if normalize:
    text = normalize_text(text, language)
    print("normalize_text ", text)
  while len(text):
    m = _curly_re.match(text)
    if not m:
      sequence += _symbols_to_sequence(_clean_text(text,
                                                   cleaner_names), language)
      break
    sequence += _symbols_to_sequence(_clean_text(m.group(1),
                                                 cleaner_names), language)
    sequence += _arpabet_to_sequence(m.group(2), language)
    text = m.group(3)

  return sequence


def sequence_to_text(sequence, language):
  if language == 'vn':
    _id_to_symbol = vn_id_to_symbol
  else:
    _id_to_symbol = en_id_to_symbol

  result = ''
  for symbol_id in sequence:
    if symbol_id in _id_to_symbol:
      s = _id_to_symbol[symbol_id]

      if len(s) > 1 and s[0] == '@':
        s = '{%s}' % s[1:]
      result += s
  return result.replace('}{', ' ')


def _clean_text(text, cleaner_names):
  for name in cleaner_names:
    cleaner = getattr(cleaners, name)
    if not cleaner:
      raise Exception('Unknown cleaner: %s' % name)
    text = cleaner(text)
  return text


def _symbols_to_sequence(symbols, language):
  if language == 'vn':
    _symbol_to_id = vn_symbol_to_id
  else:
    _symbol_to_id = en_symbol_to_id
  return [_symbol_to_id[s] for s in symbols if _should_keep_symbol(s, _symbol_to_id)]


def _arpabet_to_sequence(text, language):
  return _symbols_to_sequence(['@' + s for s in text.split()], language)


def _should_keep_symbol(s, _symbol_to_id):
  return s in _symbol_to_id and s is not '_' and s is not '~'
