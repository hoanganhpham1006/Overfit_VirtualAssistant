from matplotlib import pyplot as plt
import cv2
import numpy as np


def plot_image(img, size = 10):
    if img is not None:
        if(len(img.shape) == 3):
            cmap = None
        else:
            cmap = "gray"
        plt.figure(figsize=(size, size))
        plt.imshow(img, cmap=cmap)
        plt.show()

def plot_images(images, size = 10):
    imgs = []
    for img in images:
        if img is not None:
            imgs.append(img)
    n = len(imgs)
    if n == 0:
        return
    elif n == 1:
        plot_image(imgs[0], size=5)
    else:
        fig, axs = plt.subplots(1,n, figsize=(size, size*n))
        for (i, img) in enumerate(imgs):
            if(len(img.shape) == 3):
                cmap = None
            else:
                cmap = "gray"
            axs[i].imshow(img, cmap=cmap)
        plt.show() 
        
        

def visualize_landmark(img, points, put_text=True, text_scale=0.2):
    img_copy = img.copy()
    points = np.array(points)
    points = np.squeeze(points)

    for i, pt in enumerate(points):
        coord = (pt[0], pt[1])
        if put_text:
            cv2.putText(img_copy, str(i), coord, cv2.FONT_HERSHEY_SIMPLEX, text_scale, (0,255, 0))
        else:
            cv2.circle(img_copy, coord, 1, (0,255, 0), 1) 
    return img_copy
  
  
def visualize_mask(img, mask):
    new_mask = np.zeros_like(img)
    color = np.reshape([255, 255, 255], (1, 1, 3))
    new_mask[(mask==255).all(axis=2)] = color
    
    img_copy = img.copy()
    visualized_img = cv2.addWeighted(img_copy,0.8, new_mask,0.2,0)
    return visualized_img